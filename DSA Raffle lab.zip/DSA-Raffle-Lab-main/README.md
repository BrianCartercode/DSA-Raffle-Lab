# DSA-Raffle-Lab
A java project that allows the user to add items to a raffle, buy a ticket and select a winner.
